package com.example.quick_start

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
